#ifndef _XENO_ASM_GENERIC_BITS_SIGSHADOW_H
#define _XENO_ASM_GENERIC_BITS_SIGSHADOW_H

void xeno_sigshadow_install_once(void);

#endif /* _XENO_ASM_GENERIC_BITS_SIGSHADOW_H */

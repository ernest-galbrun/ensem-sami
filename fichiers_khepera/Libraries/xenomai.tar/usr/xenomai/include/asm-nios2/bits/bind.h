#ifndef _XENO_ASM_NIOS2_BIND_H
#define _XENO_ASM_NIOS2_BIND_H

#include <asm-generic/xenomai/bits/bind.h>

#endif /* _XENO_ASM_NIOS2_BIND_H */
